# logger
logger library

## Installation
```console
pip install git+https://github.com/cm107/logger#egg=logger
```