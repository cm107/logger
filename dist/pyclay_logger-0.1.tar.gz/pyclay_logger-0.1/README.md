# logger
logger library

## Installation
### Install From Github
```console
pip install https://github.com/cm107/logger/archive/0.1.zip
```

### Install From Pypi
```console
pip install pyclay_logger==0.1
```