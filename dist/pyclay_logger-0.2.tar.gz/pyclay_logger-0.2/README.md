# logger
logger library

## Installation
### Install From Github
```console
pip install https://github.com/cm107/logger/archive/0.2.zip
```

### Install From Pypi
```console
pip install pyclay-logger==0.2
```
