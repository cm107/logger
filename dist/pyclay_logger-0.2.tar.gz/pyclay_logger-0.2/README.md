# logger
logger library

## Installation
### Install From Github
```console
pip install https://github.com/cm107/logger/archive/master.zip
```

### Install From Pypi
```console
pip install pyclay-logger
```
